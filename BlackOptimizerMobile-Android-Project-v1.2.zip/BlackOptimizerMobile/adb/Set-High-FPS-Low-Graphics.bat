@echo off
setlocal
where adb >nul 2>nul || (echo ADB not found. Install Android SDK Platform-Tools and add adb to PATH.& pause & exit /b 1)
echo Connect the Nubia A36 with USB debugging enabled and approve the prompt.
adb wait-for-device

echo Requesting the panel's 90Hz mode and quicker UI animations...
adb shell settings put system peak_refresh_rate 90.0
adb shell settings put system min_refresh_rate 90.0
adb shell settings put global window_animation_scale 0.5
adb shell settings put global transition_animation_scale 0.5
adb shell settings put global animator_duration_scale 0.5

echo.
echo Asking Android Game Mode for PERFORMANCE mode where supported...
echo PUBG Global:
adb shell cmd game mode performance com.tencent.ig
echo PUBG Korea:
adb shell cmd game mode performance com.pubg.krmobile
echo PUBG Vietnam:
adb shell cmd game mode performance com.vng.pubgmobile
echo BGMI:
adb shell cmd game mode performance com.pubg.imobile
echo Roblox:
adb shell cmd game mode performance com.roblox.client

echo.
echo IMPORTANT:
echo - Android/OEM firmware may not implement a performance intervention for these games.
echo - This command cannot force low graphics or unlock a game's FPS cap.
echo - Set PUBG Graphics to Smooth and Frame Rate to the highest option offered in PUBG.
echo - Set Roblox Graphics Mode to Manual and Graphics Quality to the lowest level.
echo - TikTok is not a game; use TikTok Data Saver and clear its cache in the app.
echo - If the phone heats up, performance can fall due to thermal protection.
echo.
echo Display peak refresh setting:
adb shell settings get system peak_refresh_rate
echo If Nubia firmware ignores the refresh override, select 90Hz manually in Display settings if available.
pause
