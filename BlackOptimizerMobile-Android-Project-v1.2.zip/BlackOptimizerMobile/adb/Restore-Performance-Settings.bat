@echo off
setlocal
where adb >nul 2>nul || (echo ADB not found. Install Android SDK Platform-Tools and add adb to PATH.& pause & exit /b 1)
echo Connect the Nubia A36 with USB debugging enabled and approve the prompt.
adb wait-for-device
adb shell settings put global window_animation_scale 1.0
adb shell settings put global transition_animation_scale 1.0
adb shell settings put global animator_duration_scale 1.0
adb shell settings delete system peak_refresh_rate
adb shell settings delete system min_refresh_rate
for %%P in (com.tencent.ig com.pubg.krmobile com.vng.pubgmobile com.pubg.imobile com.roblox.client) do adb shell cmd game mode standard %%P
echo.
echo Restored 1x animations, removed display overrides, and requested standard game mode.
echo Some commands may be ignored by Nubia firmware if unsupported.
pause
