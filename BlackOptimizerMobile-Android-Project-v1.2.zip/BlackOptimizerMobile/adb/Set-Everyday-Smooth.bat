@echo off
setlocal
where adb >nul 2>nul || (echo ADB not found. Install Android SDK Platform-Tools and add adb to PATH.& pause & exit /b 1)
echo Connect the Nubia A36 with USB debugging enabled and approve the prompt.
adb wait-for-device
adb shell settings put global window_animation_scale 0.5
adb shell settings put global transition_animation_scale 0.5
adb shell settings put global animator_duration_scale 0.5
echo.
echo Set Android UI animations to 0.5x for shorter transitions.
echo This can make the interface feel quicker but does not increase CPU/GPU performance or fix hardware/firmware faults.
echo Current animation settings:
adb shell settings get global window_animation_scale
adb shell settings get global transition_animation_scale
adb shell settings get global animator_duration_scale
pause
