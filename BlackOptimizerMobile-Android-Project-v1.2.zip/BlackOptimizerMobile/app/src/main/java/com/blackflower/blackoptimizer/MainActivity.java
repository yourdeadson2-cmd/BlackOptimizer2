package com.blackflower.blackoptimizer;

import android.app.Activity;
import android.app.ActivityManager;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.net.Uri;
import android.os.BatteryManager;
import android.os.Bundle;
import android.os.Environment;
import android.os.StatFs;
import android.provider.Settings;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.Display;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import android.content.pm.ResolveInfo;
import android.content.pm.PackageManager;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.io.File;
import java.util.Locale;

public class MainActivity extends Activity {
    private final int bg = Color.rgb(9,10,15), panel = Color.rgb(20,22,31), muted = Color.rgb(151,157,174);
    private TextView ramValue, storageValue, tempValue, statusValue, gameModeValue, refreshRateValue;
    private String selectedGamePackage = null;
    private String selectedGameName = "No game selected";
    private LinearLayout root;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(bg); getWindow().setNavigationBarColor(bg);
        buildUi(); refreshStats();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true);
        root = new LinearLayout(this); root.setOrientation(LinearLayout.VERTICAL); root.setPadding(dp(20), dp(18), dp(20), dp(30)); root.setBackgroundColor(bg);
        scroll.addView(root); setContentView(scroll);

        TextView brand = text("BLACKOPTIMIZER", 13, 0xFFA78BFA, true); brand.setLetterSpacing(.16f); root.addView(brand);
        TextView title = text("Device performance", 28, Color.WHITE, true); LinearLayout.LayoutParams tp = params(-1,-2); tp.topMargin=dp(8); root.addView(title,tp);
        TextView subtitle = text("Nubia A36 • Smart device care", 14, muted, false); root.addView(subtitle);

        LinearLayout hero = card(); LinearLayout.LayoutParams hp=params(-1,-2); hp.topMargin=dp(22); root.addView(hero,hp);
        TextView over = text("ONE-TAP DEVICE CHECK", 11, 0xFFA78BFA, true); hero.addView(over);
        statusValue = text("Ready to analyze your phone", 18, Color.WHITE, true); LinearLayout.LayoutParams sp=params(-1,-2); sp.topMargin=dp(9); hero.addView(statusValue,sp);
        TextView desc = text("Checks memory, storage and battery temperature. Applies only safe actions this app is allowed to perform.", 13, muted, false); LinearLayout.LayoutParams dp1=params(-1,-2); dp1.topMargin=dp(7); hero.addView(desc,dp1);
        Button boost = button("✦   AUTO OPTIMIZE"); LinearLayout.LayoutParams bp=params(-1,dp(52)); bp.topMargin=dp(18); hero.addView(boost,bp);
        boost.setOnClickListener(v -> autoOptimize());

        TextView metricsTitle=text("LIVE DEVICE STATUS",12,muted,true); LinearLayout.LayoutParams mt=params(-1,-2); mt.topMargin=dp(24); root.addView(metricsTitle,mt);
        LinearLayout row1=new LinearLayout(this); row1.setOrientation(LinearLayout.HORIZONTAL); LinearLayout.LayoutParams rp=params(-1,-2); rp.topMargin=dp(10); root.addView(row1,rp);
        ramValue=metric(row1,"MEMORY USED","Reading…"); storageValue=metric(row1,"FREE STORAGE","Reading…");
        LinearLayout row2=new LinearLayout(this); row2.setOrientation(LinearLayout.HORIZONTAL); LinearLayout.LayoutParams r2=params(-1,-2); r2.topMargin=dp(10); root.addView(row2,r2);
        tempValue=metric(row2,"BATTERY TEMP","Reading…"); refreshRateValue=metric(row2,"DISPLAY REFRESH","Reading…");
        addGameBooster();
        addAppProfiles();

        section("SMART TOOLS", "Real actions, no fake boost counters");
        tool("Background app controls", "Open Android's app and battery controls to restrict apps you choose.", "OPEN APP CONTROLS", v -> openAppControls());
        tool("TikTok cache manager", "Open TikTok's Android app storage page. Review cache before clearing it; clearing cache may cause a temporary reload.", "MANAGE TIKTOK STORAGE", v -> openAppInfo("com.zhiliaoapp.musically"));
        tool("Game performance setup", "Open display settings and Android game controls when supported by your firmware.", "OPEN DISPLAY SETTINGS", v -> openDisplaySettings());
        tool("Usage access", "Optional access lets Android show app usage information. This app does not collect or upload it.", "OPEN USAGE ACCESS", v -> openUsageAccess());
        tool("Refresh device readings", "Update memory, storage and battery readings.", "REFRESH STATUS", v -> refreshStats());

        TextView note=text("HONEST PERFORMANCE NOTES",12,0xFFA78BFA,true); LinearLayout.LayoutParams np=params(-1,-2); np.topMargin=dp(22); root.addView(note,np);
        TextView foot=text("Android does not let ordinary apps kill other apps, clear another app's private cache, force a game's resolution, or raise system CPU priority. FPS for other apps also requires privileged access. BlackOptimizer will not fake these controls or promise an FPS/ping increase.",13,muted,false); LinearLayout.LayoutParams fp=params(-1,-2); fp.topMargin=dp(9); root.addView(foot,fp);
        TextView version=text("BLACKOPTIMIZER MOBILE  •  VERSION 1.2.0",10,0xFF626879,true); LinearLayout.LayoutParams vp=params(-1,-2); vp.topMargin=dp(28); root.addView(version,vp);
    }

    private void addGameBooster() {
        section("GAME BOOSTER", "Choose performance over graphics, or balance both");
        LinearLayout c=card(); LinearLayout.LayoutParams cp=params(-1,-2); cp.topMargin=dp(10); root.addView(c,cp);
        gameModeValue=text("PROFILE: HIGH FPS + LOW GRAPHICS",16,Color.WHITE,true); c.addView(gameModeValue);
        TextView explain=text("High FPS mode is designed to reduce graphics workload: choose the lowest in-game graphics quality and the highest stable frame-rate option. BlackOptimizer cannot force another game's renderer or unlock FPS beyond the game/device limit.",13,muted,false); LinearLayout.LayoutParams ep=params(-1,-2); ep.topMargin=dp(7); c.addView(explain,ep);
        Button high=button("⚡  HIGH FPS + LOW GRAPHICS"); LinearLayout.LayoutParams hp=params(-1,dp(46)); hp.topMargin=dp(13); c.addView(high,hp); high.setOnClickListener(v -> selectGameMode("HIGH FPS + LOW GRAPHICS"));
        Button balanced=button("BALANCED PERFORMANCE"); LinearLayout.LayoutParams bp=params(-1,dp(46)); bp.topMargin=dp(8); c.addView(balanced,bp); balanced.setOnClickListener(v -> selectGameMode("BALANCED PERFORMANCE"));
        Button quality=button("HIGH QUALITY"); LinearLayout.LayoutParams qp=params(-1,dp(46)); qp.topMargin=dp(8); c.addView(quality,qp); quality.setOnClickListener(v -> selectGameMode("HIGH QUALITY"));
        Button choose=button("CHOOSE / LAUNCH A GAME"); LinearLayout.LayoutParams gp=params(-1,dp(46)); gp.topMargin=dp(8); c.addView(choose,gp); choose.setOnClickListener(v -> showGamePicker());
        Button display=button("OPEN 90Hz DISPLAY SETTINGS"); LinearLayout.LayoutParams dp1=params(-1,dp(46)); dp1.topMargin=dp(8); c.addView(display,dp1); display.setOnClickListener(v -> openDisplaySettings());
        TextView everyday=text("EVERYDAY SMOOTHNESS",12,0xFFA78BFA,true); LinearLayout.LayoutParams ep2=params(-1,-2); ep2.topMargin=dp(18); root.addView(everyday,ep2);
        TextView everydayDesc=text("Use the optional Windows ADB presets in the project folder to set Android animations to 0.5x and request the phone's supported 90Hz refresh mode. The restore script returns animations to 1x and removes the refresh-rate override.",13,muted,false); LinearLayout.LayoutParams edp=params(-1,-2); edp.topMargin=dp(6); root.addView(everydayDesc,edp);
    }

    private void addAppProfiles() {
        section("APP-SPECIFIC PROFILES", "Practical low-quality / highest-available-FPS setup guides");
        appProfileCard("PUBG MOBILE", "LOW / SMOOTH GRAPHICS  •  HIGHEST STABLE FPS", "PUBG");
        appProfileCard("ROBLOX", "MANUAL GRAPHICS  •  LOWEST QUALITY", "ROBLOX");
        appProfileCard("TIKTOK", "SMOOTHER FEED  •  LOWER VIDEO DATA", "TIKTOK");
    }

    private void appProfileCard(String title, String subtitle, String key) {
        LinearLayout c=card(); LinearLayout.LayoutParams cp=params(-1,-2); cp.topMargin=dp(10); root.addView(c,cp);
        c.addView(text(title,17,Color.WHITE,true));
        TextView sub=text(subtitle,11,0xFFA78BFA,true); LinearLayout.LayoutParams slp=params(-1,-2); slp.topMargin=dp(5); c.addView(sub,slp);
        Button guide=button("VIEW OPTIMIZED SETTINGS"); LinearLayout.LayoutParams glp=params(-1,dp(44)); glp.topMargin=dp(11); c.addView(guide,glp);
        guide.setOnClickListener(v -> showAppProfile(key));
        Button launch=button("OPEN " + title); LinearLayout.LayoutParams llp=params(-1,dp(44)); llp.topMargin=dp(7); c.addView(launch,llp);
        launch.setOnClickListener(v -> launchTarget(key));
    }

    private void showAppProfile(String key) {
        String title, message;
        if (key.equals("PUBG")) {
            title="PUBG MOBILE — FPS PRIORITY";
            message="In PUBG: Settings → Graphics & Audio.\n\n• Graphics: Smooth (or the lowest option available).\n• Frame Rate: choose the highest option the game actually offers and that remains stable.\n• Anti-aliasing: Off, if available.\n• Shadows: Off, if available.\n• Auto-adjust graphics: enable only if frame drops continue and the game offers it.\n\nThe available FPS choices depend on PUBG's device whitelist and game version. BlackOptimizer cannot unlock a hidden 60/90 FPS option or edit PUBG's renderer.";
        } else if (key.equals("ROBLOX")) {
            title="ROBLOX — FPS PRIORITY";
            message="While in a Roblox experience: open the Roblox menu → Settings.\n\n• Graphics Mode: Manual.\n• Graphics Quality: move the slider to the lowest level (left).\n• Close unnecessary overlays and keep the phone cool.\n\nRoblox controls its own frame-rate cap. A 90Hz screen does not guarantee 90 FPS; this app cannot bypass Roblox's cap or force its internal resolution.";
        } else {
            title="TIKTOK — SMOOTHER SCROLLING";
            message="TikTok is not a game, so a game FPS/graphics profile cannot force its video frame rate. For a lighter experience: \n\n• TikTok → Profile → ☰ → Settings and privacy → Data Saver (turn on to reduce video data/quality where offered).\n• Settings and privacy → Free up space → clear Cache. Do not clear app data unless you understand it may sign you out or remove local drafts.\n• Keep storage free and update TikTok from the Play Store.\n\nData Saver may reduce video quality and buffering; it does not increase the phone's UI FPS.";
        }
        new AlertDialog.Builder(this).setTitle(title).setMessage(message).setPositiveButton("OK",null).show();
    }

    private void launchTarget(String key) {
        String[] packages;
        if (key.equals("PUBG")) packages=new String[]{"com.tencent.ig","com.pubg.krmobile","com.vng.pubgmobile","com.pubg.imobile"};
        else if (key.equals("ROBLOX")) packages=new String[]{"com.roblox.client"};
        else packages=new String[]{"com.zhiliaoapp.musically","com.ss.android.ugc.trill"};
        PackageManager pm=getPackageManager();
        for(String pkg:packages) {
            Intent launch=pm.getLaunchIntentForPackage(pkg);
            if(launch!=null) { startActivity(launch); return; }
        }
        Toast.makeText(this,key+" was not found. Install it or open it from your app list.",Toast.LENGTH_LONG).show();
    }

    private void selectGameMode(String mode) {
        if(gameModeValue!=null) gameModeValue.setText("PROFILE: "+mode);
        String message;
        if(mode.startsWith("HIGH FPS")) message="For the best chance of stable FPS, open the game's settings and set Graphics Quality to Low / Smooth, turn off shadows and effects if available, and select the highest frame-rate option the game offers. Keep the phone cool and close overlays you do not need.";
        else if(mode.startsWith("BALANCED")) message="Use medium or low graphics and the game's stable/medium frame-rate option. This balances visual quality, heat and battery use.";
        else message="Use higher graphics only if the game remains smooth. Higher quality can reduce FPS and increase heat on this hardware.";
        new AlertDialog.Builder(this).setTitle(mode).setMessage(message).setPositiveButton("OK",null).show();
    }

    private void showGamePicker() {
        Intent query=new Intent(Intent.ACTION_MAIN,null); query.addCategory(Intent.CATEGORY_LAUNCHER);
        PackageManager pm=getPackageManager(); List<ResolveInfo> apps=pm.queryIntentActivities(query,0);
        Collections.sort(apps, new Comparator<ResolveInfo>() { public int compare(ResolveInfo a, ResolveInfo b) { return String.CASE_INSENSITIVE_ORDER.compare(a.loadLabel(pm).toString(),b.loadLabel(pm).toString()); }});
        List<ResolveInfo> filtered=new ArrayList<>(); List<String> labels=new ArrayList<>();
        for(ResolveInfo ri:apps) { String pkg=ri.activityInfo.packageName; if(!pkg.equals(getPackageName())) { filtered.add(ri); labels.add(ri.loadLabel(pm).toString()); }}
        if(filtered.isEmpty()) { Toast.makeText(this,"No launchable apps found",Toast.LENGTH_SHORT).show(); return; }
        String[] names=labels.toArray(new String[0]);
        new AlertDialog.Builder(this).setTitle("Choose a game or app").setItems(names,(dialog,which)->{
            ResolveInfo ri=filtered.get(which); selectedGamePackage=ri.activityInfo.packageName; selectedGameName=labels.get(which);
            Toast.makeText(this,"Selected: "+selectedGameName,Toast.LENGTH_SHORT).show();
            selectGameMode("HIGH FPS + LOW GRAPHICS");
            Intent launch=pm.getLaunchIntentForPackage(selectedGamePackage);
            if(launch!=null) startActivity(launch); else Toast.makeText(this,"Could not launch this app",Toast.LENGTH_SHORT).show();
        }).setNegativeButton("Cancel",null).show();
    }

    private void autoOptimize() {
        // A normal Android app may safely clear only its own cache. No other app data is touched.
        long before = cacheSize(getCacheDir());
        deleteContents(getCacheDir()); deleteContents(getCodeCacheDir());
        long after = cacheSize(getCacheDir());
        refreshStats();
        statusValue.setText("Safe cleanup completed");
        Toast.makeText(this, "Cleared this app's temporary cache (" + formatBytes(Math.max(0,before-after)) + "). Other apps were left untouched.", Toast.LENGTH_LONG).show();
    }

    private void refreshStats() {
        ActivityManager am=(ActivityManager)getSystemService(ACTIVITY_SERVICE);
        ActivityManager.MemoryInfo mi=new ActivityManager.MemoryInfo(); am.getMemoryInfo(mi);
        long total=mi.totalMem, used=total-mi.availMem;
        if(ramValue!=null) ramValue.setText(formatBytes(used)+" / "+formatBytes(total));
        StatFs fs=new StatFs(Environment.getDataDirectory().getAbsolutePath());
        if(storageValue!=null) storageValue.setText(formatBytes(fs.getAvailableBytes())+" free");
        if(refreshRateValue!=null) { try { Display d=getWindowManager().getDefaultDisplay(); float hz=d.getRefreshRate(); Display.Mode[] modes=d.getSupportedModes(); float max=hz; for(Display.Mode m:modes) max=Math.max(max,m.getRefreshRate()); refreshRateValue.setText(String.format(Locale.US,"%.0fHz (max %.0f)",hz,max)); } catch(Exception e) { refreshRateValue.setText("Unavailable"); } }
        Intent b=registerReceiver(null,new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        if(b!=null && tempValue!=null) { int t=b.getIntExtra(BatteryManager.EXTRA_TEMPERATURE,-1); tempValue.setText(t>0?String.format(Locale.US,"%.1f °C",t/10f):"Unavailable"); }
    }

    private void openAppControls() { try { startActivity(new Intent(Settings.ACTION_APPLICATION_SETTINGS)); } catch(Exception e) { openSettings(); } }
    private void openUsageAccess() { try { startActivity(new Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS)); } catch(Exception e) { openSettings(); } }
    private void openDisplaySettings() { try { startActivity(new Intent(Settings.ACTION_DISPLAY_SETTINGS)); } catch(Exception e) { openSettings(); } }
    private void openSettings() { try { startActivity(new Intent(Settings.ACTION_SETTINGS)); } catch(Exception ignored) {} }
    private void openAppInfo(String pkg) { try { startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:"+pkg))); } catch(Exception e) { Toast.makeText(this,"TikTok app info could not be opened. Is TikTok installed?",Toast.LENGTH_LONG).show(); } }

    private void tool(String name,String detail,String action,View.OnClickListener click) {
        LinearLayout c=card(); LinearLayout.LayoutParams cp=params(-1,-2); cp.topMargin=dp(10); root.addView(c,cp);
        c.addView(text(name,17,Color.WHITE,true)); TextView d=text(detail,13,muted,false); LinearLayout.LayoutParams dlp=params(-1,-2); dlp.topMargin=dp(6); c.addView(d,dlp);
        Button b=button(action); LinearLayout.LayoutParams blp=params(-1,dp(44)); blp.topMargin=dp(12); c.addView(b,blp); b.setOnClickListener(click);
    }
    private TextView metric(LinearLayout row,String label,String value) {
        LinearLayout c=card(); LinearLayout.LayoutParams p=new LinearLayout.LayoutParams(0,dp(98),1); p.rightMargin=dp(5); p.leftMargin=dp(5); row.addView(c,p);
        c.addView(text(label,10,muted,true)); TextView v=text(value,16,Color.WHITE,true); LinearLayout.LayoutParams vp=params(-1,-2); vp.topMargin=dp(12); c.addView(v,vp); return v;
    }
    private void section(String a,String b) { TextView t=text(a,12,muted,true); LinearLayout.LayoutParams p=params(-1,-2); p.topMargin=dp(24); root.addView(t,p); TextView s=text(b,13,muted,false); root.addView(s); }
    private LinearLayout card() { LinearLayout l=new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); l.setPadding(dp(16),dp(16),dp(16),dp(16)); GradientDrawable g=new GradientDrawable(); g.setColor(panel); g.setCornerRadius(dp(18)); l.setBackground(g); return l; }
    private Button button(String s) { Button b=new Button(this); b.setText(s); b.setTextColor(Color.WHITE); b.setTextSize(12); b.setTypeface(Typeface.DEFAULT,Typeface.BOLD); b.setAllCaps(false); GradientDrawable g=new GradientDrawable(); g.setColor(0xFF6941C6); g.setCornerRadius(dp(13)); b.setBackground(g); if(android.os.Build.VERSION.SDK_INT>=21)b.setStateListAnimator(null); return b; }
    private TextView text(String s,int size,int color,boolean bold) { TextView t=new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color); if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD); return t; }
    private LinearLayout.LayoutParams params(int w,int h) { return new LinearLayout.LayoutParams(w,h); }
    private int dp(int n) { return (int)(n*getResources().getDisplayMetrics().density+.5f); }
    private long cacheSize(File f) { if(!f.exists())return 0; if(f.isFile())return f.length(); long n=0; File[] a=f.listFiles(); if(a!=null)for(File x:a)n+=cacheSize(x); return n; }
    private void deleteContents(File f) { File[] a=f.listFiles(); if(a!=null)for(File x:a){ if(x.isDirectory())deleteContents(x); x.delete(); } }
    private String formatBytes(long n) { if(n<1024)return n+" B"; double v=n; String[] u={"KB","MB","GB","TB"}; int i=-1; do{v/=1024;i++;}while(v>=1024&&i<u.length-1); return String.format(Locale.US,"%.1f %s",v,u[i]); }
}
