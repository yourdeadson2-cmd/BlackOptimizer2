BLACKOPTIMIZER MOBILE - ANDROID PROJECT
Package: com.blackflower.blackoptimizer
Version: 1.2.0
Minimum Android: 8.0 (API 26)
Compile SDK: 35

BUILD THE APK ON WINDOWS
1. Install Android Studio from https://developer.android.com/studio
2. Extract this project folder.
3. Open the BlackOptimizerMobile folder in Android Studio.
4. Allow Android Studio to download the Android Gradle Plugin and Android SDK Platform 35 if asked.
5. Select Build > Build Bundle(s) / APK(s) > Build APK(s).
6. The debug APK will be created at app\build\outputs\apk\debug\app-debug.apk.
7. Transfer that APK to the Nubia A36 and install it.

APP-SPECIFIC PROFILES
PUBG MOBILE:
- In PUBG Settings > Graphics & Audio, choose Smooth (or the lowest graphics option) and the highest frame-rate option the game actually offers and that stays stable.
- Turn Anti-aliasing and Shadows off if those options are available.
- Available frame-rate tiers are controlled by PUBG's device whitelist, game version and thermal conditions. BlackOptimizer does not unlock hidden FPS tiers or alter PUBG files.

ROBLOX:
- In an experience, open Roblox menu > Settings.
- Set Graphics Mode to Manual and Graphics Quality to the lowest level.
- Roblox controls its own frame-rate cap. The screen refresh rate is not the same as the game's rendered FPS.

TIKTOK:
- TikTok is not a game; a third-party booster cannot force its video frame rate or render resolution.
- TikTok > Profile > menu > Settings and privacy > Data Saver can reduce video data/quality where available. This may reduce data use/buffering but does not increase Android UI FPS.
- TikTok > Settings and privacy > Free up space > clear Cache. Avoid clearing app data unless you understand it may sign you out or remove local drafts.

OPTIONAL WINDOWS ADB PRESET
- Enable Developer options, USB debugging, connect the phone and approve the RSA prompt.
- Install Android SDK Platform-Tools and make sure adb is on PATH.
- Run adb\Set-High-FPS-Low-Graphics.bat. It requests the 90Hz display policy, sets animations to 0.5x and asks Android Game Mode for PERFORMANCE mode for common PUBG package variants and Roblox.
- Android/OEM firmware may ignore Game Mode commands or have no configured game intervention. The command cannot force lower graphics or unlock FPS tiers. Verify the output on the connected phone.
- TikTok is deliberately excluded from Android Game Mode commands because it is not a game.
- Run adb\Restore-Performance-Settings.bat to restore 1x animations, remove display overrides and request standard game mode.

EXACT CAPABILITY LIMITS
- Samsung Game Booster Plus has privileged Samsung/OEM integration that controls per-game FPS, resolution, and CPU/GPU allocation. A normal third-party APK on stock Nubia firmware does not receive those privileges.
- BlackOptimizer's game profiles are real, app-specific setup guides and launch shortcuts. They do not inject into games, rewrite game files, spoof FPS, or silently change their private graphics settings.
- Android Game Mode PERFORMANCE is requested through ADB only where supported. OEM behavior varies and is not guaranteed to raise FPS.
- Auto Optimize clears only BlackOptimizer's own cache. Android blocks ordinary apps from silently clearing TikTok's private cache or killing other apps.
- RAM, storage, and battery temperature are system readings. FPS for other apps is not exposed to an ordinary APK on stock Android.
- No CPU/GPU overclocking, thermal safety disabling, or ping guarantees.

NEW PHONE TROUBLESHOOTING
If TikTok, Settings, the launcher and basic scrolling all stutter badly on the first day, install official system updates, restart, and test before installing many apps. Persistent severe lag on a brand-new device may indicate firmware or hardware trouble; contact the seller promptly about exchange/return or warranty service.
